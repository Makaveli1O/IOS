#ifndef __HEADER_H
#define __HEADER_H
#include "stdio.h"
void foo_1(void);
void foo_2(void);
void foo_3(void);
void foo_4(void);
void foo_5(void);
#endif
